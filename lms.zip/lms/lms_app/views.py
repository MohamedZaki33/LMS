from django.shortcuts import render , redirect ,get_object_or_404
from .models import *
from .forms import Bookform ,Categoryform
# Create your views here.


def index(request):
    if request.method == 'POST':
        # print('no nonononononononoonononononononononoononoon')
        add_book = Bookform(request.POST, request.FILES)
        if add_book.is_valid():  # Corrected the condition here
            add_book.save()

        add_catg = Categoryform(request.POST) 
        if add_catg.is_valid():  # Corrected the condition here
            add_catg.save()
            
    context = {
        'category': Category.objects.all(),
        'books': Book.objects.all(),
        'form': Bookform(),
        'catform': Categoryform(),
        'allbooks':Book.objects.filter(active=True).count(),
        'booksold':Book.objects.filter(status='sold').count(),
        'bookavailable':Book.objects.filter(status='available').count(),
        'bookrental':Book.objects.filter(status='rental').count(),
    }
    return render(request, 'pages/index.html', context)

def books(request):
    context = {
        'category':Category.objects.all(),
        'books':Book.objects.all(),
    }
    return render(request , 'pages/books.html', context)


def update(request , id):
    book_id = Book.objects.get(id=id)
    if request.method == 'POST':
        book_save = Bookform(request.POST , request.FILES,instance=book_id)
        if book_save.is_valid():  # Corrected the condition here
            book_save.save()
            return redirect('/')
    else:
        book_save = Bookform(instance=book_id)
    context = {
        'form': book_save,
    }
    return render(request , 'pages/update.html', context)


def delete(request,id):
    book_delete = get_object_or_404(Book,id=id)
    if request.method == 'POST':
        book_delete.delete()
        return redirect('/')
    return render(request , 'pages/delete.html')


